# __all__ = ['uccsd', 'qaoa', 'ising', 'molecule', 'rand', 'pauliString']

# from . import uccsd
# from . import qaoa
# from . import ising
# from . import molecule
# from . import hami as rand
# from .mypauli import pauliString